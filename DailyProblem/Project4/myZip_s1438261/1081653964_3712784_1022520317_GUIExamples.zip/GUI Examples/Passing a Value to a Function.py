def triple(num): 
    num = 3 * num 
    return num
    
num = 2
print(triple(num))
print(num)
