from tkinter import *

window = Tk() 
window.title("ReadOnly Entry Widget")
txtOutput = StringVar() # contents of widget
entOutput = Entry(window, width=20, state="readonly", textvariable = txtOutput) 
entOutput.grid(padx=100, pady=15)
txtOutput.set("Hello World!")
window.mainloop() 
