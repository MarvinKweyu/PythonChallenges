def main():
    list1 = [6, 4, -5, 3.5] 
    list1.sort() 
    print(list1)
    
    list2 = ["ha", "hi", 'B', '7', '&'] 
    list2.sort()
    print(list2)

    list1 = [chr(177), "cat", "car", "Dog", "dog", "8-ball", "5" + chr(162)] 
    list1.sort() 
    print(list1)

    monarchs = [("George", 5), ("Elizabeth", 2), ("George", 6), ("Elizabeth", 1)]
    monarchs.sort() 
    print(monarchs) 

main()
