def main():
    list1 = ["white", "blue", "red", "green"]
    list2 = sorted(list1)
    print(list2)
    list2 = sorted(list1, reverse=True)
    print(list2)
    list2 = sorted(list1, key=len)
    print(list2)
    list2 = sorted("virus")
    print(list2)

main()
