from tkinter import *

window = Tk() 
window.title("Label") 
lblPrincipal = Label(window, text="Introduction to Information Technology", bg = "light blue") 
lblPrincipal.grid(padx=100, pady=15) 
window.mainloop() 
