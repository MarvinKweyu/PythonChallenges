def main(): ## Extract the first name from a full name.
    fullName = input("Enter a person's full name: ") 
    print("First name:", firstName(fullName))
    
def firstName(fullName): 
    firstSpace = fullName.index(" ") 
    givenName = fullName[:firstSpace] 
    return givenName

main() 
