from tkinter import *

window = Tk() 
window.title("Entry Widget") 
entName = Entry(window, width=20) 
entName.grid(padx=100, pady=15) 
window.mainloop() 
