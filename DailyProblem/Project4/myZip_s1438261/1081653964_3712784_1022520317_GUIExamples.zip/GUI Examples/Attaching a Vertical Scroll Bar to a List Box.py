from tkinter import *

window = Tk() 
window.title("Australia") 
yscroll = Scrollbar(window, orient=VERTICAL) 
yscroll.grid(row=0, column=2, rowspan=4, padx=(0,100), pady=5, sticky=NS) 
statesList = ["Tasmania", "Australian Capital Territory", "New South Wales",
              "Northern Territory", "Queensland", "South Australia",
               "Victoria", "Western Australia"]
statesList.sort()
conOFlstNE = StringVar()
lstNE = Listbox(window, width=25, height=5, listvariable=conOFlstNE, yscrollcommand=yscroll.set) 
lstNE.grid(row=0, column=1, rowspan=4, padx=(100,0), pady=5, sticky=E) 
conOFlstNE.set(tuple(statesList))
yscroll["command"] = lstNE.yview

window.mainloop() 
