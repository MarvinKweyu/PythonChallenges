MINIMUM_VOTING_AGE = 19

def eligibleToVote(age):
    if (age >= MINIMUM_VOTING_AGE): 
        print("You are eligible to vote.")
    else:
        print("You are NOT eligible to vote.")

def main():
    inputAge = eval(input("Enter your age: "))
    eligibleToVote(inputAge)

main()
