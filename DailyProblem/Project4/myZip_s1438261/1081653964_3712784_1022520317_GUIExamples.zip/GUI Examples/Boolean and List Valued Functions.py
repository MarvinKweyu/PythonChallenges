def isVowelWord(word):
    word = word.upper() 
    vowels = ('A', 'E', 'I', 'O', 'U') 
    for vowel in vowels:
        if vowel not in word:
            return False
    return True 

def occurringVowels(word):
    word = word.upper()
    vowels = ('A', 'E', 'I', 'O', 'U') 
    includedVowels = [] 
    for vowel in vowels:
        if (vowel in word) and (vowel not in includedVowels):
            includedVowels.append(vowel)
    return includedVowels 


## Determine if a word contains every vowel. 
word = input("Enter a word: ") 
if isVowelWord(word):
    print(word, "contains every vowel.") 
else:
    print(word, "does not contain every vowel.")

print("-------------------------------------------")  

## Display the vowels appearing in a word. word = input("Enter a word: ")
listOfVowels = occurringVowels(word) 
print("The following vowels occur in the word: ", end="") 
stringOfVowels = " ".join(listOfVowels) 
print(stringOfVowels) 
