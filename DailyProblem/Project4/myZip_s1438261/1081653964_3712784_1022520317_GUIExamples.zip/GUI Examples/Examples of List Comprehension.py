def main():
    list1 = ['2', '5', '6', '7']
    ##print ([int(x) for x in list1])

    list2 = [int(x) for x in list1]
    print(list2)
    list3 = [g(x) for x in list1] 
    print(list3)

    list4 = [g(x) for x in list1 if int(x) % 2 == 1]
    print(list4)

    print([ord(x) for x in "abc"] )
    print([x ** .5 for x in (4, -1, 9) if x >= 0] )
    print([x ** 2 for x in range(3)])
    
def g(x):
    return(int(x) ** 2)

main()

