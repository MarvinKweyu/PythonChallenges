def total(w, x, y=10, z=20): 
    return (w ** x) + y + z
def main():
    print(total(2, 3))
    print(total(2, 3, 4))
    print(total(2, 3, 4, 5))

main()
