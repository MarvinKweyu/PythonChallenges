from tkinter import *
window = Tk()

def main():
    window.title("Listbox") 
    lstName = Listbox(window, width=10, height=5)
    lstName.grid(padx=100, pady=15)

    window.mainloop() 

main()
