def main(): ## Create two files containing the first three Countries.
    outfile = open("countries1.txt", 'w') 
    createWithWritelines(outfile) 
    outfile = open("countries2.txt", 'w')
    createWithWrite(outfile)
    
def createWithWritelines(outfile):
    list1 = ["Australia", "Canada", "New Zealand"] 
    # Append endline characters to the list's items.
    for i in range(len(list1)):
        list1[i] = list1[i] + "\n" # Write the list's items to the file.
    outfile.writelines(list1) 
    outfile.close()

def createWithWrite(outfile): 
    outfile.write("Australia\n")
    outfile.write("Canada\n")
    outfile.write("New Zealand\n")
    outfile.close()

main() 
