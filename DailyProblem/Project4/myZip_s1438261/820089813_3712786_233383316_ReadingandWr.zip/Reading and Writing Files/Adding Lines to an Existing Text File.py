def main(): ## Add three more countries to the file countries1.txt.
    outfile = open("countries1.txt", 'a') 
    list1 = ["America\n", "Russia\n"]
    outfile.writelines(list1)
    outfile.write("India\n") 
    outfile.close()

main() 
